# VideoLab

Android動画分析・レコーダーアプリのMVPスキャフォールド。

## できること

- **動画一覧**: MediaStoreからデバイス内の動画を読み込み
- **再生**: Media3 ExoPlayerで再生
- **ジェスチャー操作**:
  - 2本指ピンチ: ズーム(1〜8倍)+ パン
  - 左1/3を縦スワイプ: 画面明度オーバーレイ
  - 右1/3を縦スワイプ: 音量
  - 中央を横スワイプ: シーク(1画面=60秒)
  - ダブルタップ左/右: ±10秒
  - シングルタップ: コントロール表示/非表示
- **変速再生**: 0.25〜4.0倍(音声ピッチ維持)
- **次/前動画**: プレイリストナビゲーション
- **部分エフェクト**:
  - OFF / Bright+ / Shade / Mosaic を切替
  - 矩形マスク(X,Y,W,H調整) + 境界フェザー
- **書き出し(WYSIWYG)**: Transformerで現在の全エフェクトを適用してMP4保存

**重要**: プレビュー(`ExoPlayer.setVideoEffects`)と書き出し(`Transformer`)で
**完全に同じEffects listを使用**。これによりプレビュー結果 = 出力結果が保証されます。

## セットアップ

1. Android Studio Koala (2024.1.1) 以降で `settings.gradle.kts` を開く
2. Gradle Syncを実行(依存を取得)
3. 実機(物理デバイス推奨)で実行
   - エミュレータではGLエフェクト/MediaCodecがデバイスにより動作不安定

### 要件

- minSdk 24 (Android 7.0)
- targetSdk/compileSdk 34
- Kotlin 2.0.20 / Compose Compiler 2.0
- Media3 1.8.0

## プロジェクト構成

```
app/src/main/java/com/example/videolab/
├── MainActivity.kt               -- Compose entry
├── data/VideoRepository.kt       -- MediaStore query
├── ui/
│   ├── VideoListScreen.kt        -- 一覧 + 権限
│   ├── PlayerScreen.kt           -- プレイヤー本体
│   └── components/GestureOverlay.kt
├── player/PlayerViewModel.kt     -- 状態 + ExoPlayer
├── effect/
│   ├── ZoomPanEffect.kt          -- Matrixベース ズーム/パン
│   ├── MaskedRegionEffect.kt     -- GlEffect wrapper
│   └── MaskedRegionShaderProgram.kt  -- カスタムGLSL (brightness/mosaic)
└── export/VideoExporter.kt       -- Transformer書き出し
```

## 既知の制限 / TODO

- **マスク形状は矩形のみ**: 円形・ブラシは未実装(shaderに条件追加で拡張可)
- **オブジェクトトラッキング**: 未実装(MLKit/Vision統合が必要)
- **画面録画モード**: `MediaProjection`での「操作ごと録画」は未実装
- **マスク位置の視覚ガイド**: 現状はスライダーで数値指定のみ。ドラッグ可視UI要追加
- **HDR入力**: shaderがSDR前提。HDR対応にはtone-mapping検討が必要
- **Surface破棄**: `AndroidView`のfactory内`SurfaceView`はライフサイクル上で堅牢化が必要
- **エラーハンドリング**: Transformer失敗時のUIフィードバックを充実させる余地あり

## 次の開発ステップ(推奨順)

1. **マスクドラッグUI**: 矩形の四隅とエッジをComposeで描いて指でリサイズ可能に
2. **音声遅延対策**: 変速再生+書き出し時の音声同期を実機で検証
3. **プリセット保存**: マスク位置・エフェクト設定をDataStoreで永続化
4. **画面録画**: `MediaProjection` で「操作ごと動画化」モードを追加
5. **円形/ブラシマスク**: フラグメントシェーダーに形状分岐を追加

## デバッグのコツ

- GLエフェクトがおかしい場合: `adb logcat | grep -E "Transformer|VideoFrameProcess"`
- プレビューと書き出しで結果が違う場合: ExoPlayerとTransformerは色空間処理が異なるので、
  `Presentation` effectを先頭に入れて強制的に揃える
- 4K動画で遅い場合: minSdk端末では `Presentation.createForHeight(1080)` でプリスケール

## ライセンス

学習・改変自由。本番公開時はMedia3のApache 2.0ライセンス遵守。
