package com.example.videolab.effect

import android.graphics.Matrix
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation

/**
 * Zoom and pan effect using a 2D Matrix.
 *
 * Media3 passes coordinates in NDC (-1..1 with origin at center).
 * We scale around the given anchor (in NDC), then translate.
 *
 * This same effect works for:
 *  - Real-time preview via ExoPlayer.setVideoEffects(...)
 *  - Export via Transformer (EditedMediaItem.setEffects)
 * ensuring WYSIWYG output.
 */
@UnstableApi
class ZoomPanEffect(
    private val stateProvider: () -> ZoomPanState,
) : MatrixTransformation {

    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val s = stateProvider()
        val m = Matrix()
        // Scale around anchor (NDC)
        m.postScale(s.scale, s.scale, s.anchorNdcX, s.anchorNdcY)
        // Translate (pan)
        m.postTranslate(s.translateNdcX, s.translateNdcY)
        return m
    }
}

data class ZoomPanState(
    val scale: Float = 1f,
    val anchorNdcX: Float = 0f,
    val anchorNdcY: Float = 0f,
    val translateNdcX: Float = 0f,
    val translateNdcY: Float = 0f,
)
