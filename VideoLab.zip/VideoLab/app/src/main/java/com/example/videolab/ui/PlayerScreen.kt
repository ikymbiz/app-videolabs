package com.example.videolab.ui

import android.net.Uri
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import com.example.videolab.effect.MaskedRegionState
import com.example.videolab.export.VideoExporter
import com.example.videolab.player.PlayerViewModel
import com.example.videolab.ui.components.GestureOverlay
import kotlinx.coroutines.launch
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    videos: List<Uri>,
    startIndex: Int,
    onExit: () -> Unit,
) {
    val vm: PlayerViewModel = viewModel()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val zoomPan by vm.zoomPan.collectAsState()
    val mask by vm.mask.collectAsState()
    val speed by vm.speed.collectAsState()
    val volume by vm.volume.collectAsState()
    val brightnessOverlay by vm.brightnessOverlay.collectAsState()
    val currentIndex by vm.currentIndex.collectAsState()

    // Load videos once
    LaunchedEffect(videos) {
        if (videos.isNotEmpty()) vm.setVideos(videos, startIndex)
    }

    DisposableEffect(Unit) {
        onDispose { /* ViewModel releases player */ }
    }

    var controlsVisible by remember { mutableStateOf(true) }
    var exporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableStateOf(0) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // The video surface. Media3 renders effects to this surface.
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                SurfaceView(ctx).also { vm.player.setVideoSurfaceView(it) }
            }
        )

        // Brightness simulated via black/white overlay (ties to left-swipe)
        val overlayColor =
            if (brightnessOverlay < 0) Color.Black.copy(alpha = abs(brightnessOverlay).coerceAtMost(0.8f))
            else Color.White.copy(alpha = brightnessOverlay.coerceAtMost(0.4f))
        Box(Modifier.fillMaxSize().background(overlayColor))

        // Visual mask rectangle guide (thin border) when a mask effect is active
        if (mask.mode != 0) {
            MaskRectGuide(mask)
        }

        // Gesture layer
        GestureOverlay(
            onBrightnessDelta = { vm.adjustBrightness(it) },
            onVolumeDelta = { vm.adjustVolume(it) },
            onSeekDeltaMs = { vm.seekBy(it) },
            onZoomPan = { scaleDelta, pan, _, size ->
                vm.updateZoom { s ->
                    val newScale = (s.scale * scaleDelta).coerceIn(1f, 8f)
                    // Convert pan pixels -> NDC translation
                    val txNdc = s.translateNdcX + (pan.x / size.width) * 2f
                    val tyNdc = s.translateNdcY - (pan.y / size.height) * 2f
                    s.copy(
                        scale = newScale,
                        translateNdcX = txNdc,
                        translateNdcY = tyNdc
                    )
                }
            },
            onDoubleTapLeft = { vm.seekBy(-10_000) },
            onDoubleTapRight = { vm.seekBy(10_000) },
            onTap = { controlsVisible = !controlsVisible },
        )

        // Top bar
        if (controlsVisible) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(WindowInsets.statusBars.asPaddingValues())
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onExit) {
                    Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                }
                Text(
                    "${currentIndex + 1}/${videos.size}",
                    color = Color.White,
                    modifier = Modifier.padding(start = 8.dp)
                )
                Box(Modifier.width(0.dp).fillMaxWidth(1f))
                IconButton(
                    onClick = {
                        scope.launch {
                            exporting = true
                            exportProgress = 0
                            try {
                                VideoExporter(context).export(
                                    sourceUri = videos[currentIndex],
                                    effects = vm.buildEffects(),
                                    onProgress = { exportProgress = it }
                                )
                            } finally {
                                exporting = false
                            }
                        }
                    },
                    enabled = !exporting
                ) {
                    Icon(Icons.Default.FileDownload, "export", tint = Color.White)
                }
            }
        }

        // Bottom controls panel
        if (controlsVisible) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(WindowInsets.navigationBars.asPaddingValues())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Transport row
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { vm.prev() }) {
                        Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                    }
                    IconButton(onClick = { vm.seekBy(-10_000) }) {
                        Icon(Icons.Default.FastRewind, null, tint = Color.White)
                    }
                    PlayPauseButton(vm)
                    IconButton(onClick = { vm.seekBy(10_000) }) {
                        Icon(Icons.Default.FastForward, null, tint = Color.White)
                    }
                    IconButton(onClick = { vm.next() }) {
                        Icon(Icons.Default.SkipNext, null, tint = Color.White)
                    }
                    IconButton(onClick = {
                        vm.updateZoom { it.copy(scale = 1f, translateNdcX = 0f, translateNdcY = 0f) }
                    }) {
                        Icon(Icons.Default.Close, "reset zoom", tint = Color.White)
                    }
                }

                // Speed slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, null, tint = Color.White)
                    Text(
                        "%.2fx".format(speed),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Slider(
                        value = speed,
                        onValueChange = { vm.setSpeed(it) },
                        valueRange = 0.25f..4f,
                        steps = 14,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Mask mode row
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ModeChip("OFF", mask.mode == 0) { vm.updateMask { it.copy(mode = 0) } }
                    ModeChip("Bright+", mask.mode == 1 && mask.brightness > 0) {
                        vm.updateMask { it.copy(mode = 1, brightness = 0.4f) }
                    }
                    ModeChip("Shade", mask.mode == 1 && mask.brightness < 0) {
                        vm.updateMask { it.copy(mode = 1, brightness = -0.4f) }
                    }
                    ModeChip("Mosaic", mask.mode == 2) {
                        vm.updateMask { it.copy(mode = 2) }
                    }
                }

                // Mask rect adjust (simple sliders)
                if (mask.mode != 0) {
                    MaskControls(
                        state = mask,
                        onChange = { vm.updateMask { _ -> it } }
                    )
                }

                Text(
                    "zoom ${"%.2f".format(zoomPan.scale)}x · vol ${"%.0f".format(volume * 100)}%",
                    color = Color.Gray
                )
            }
        }

        // Export overlay
        if (exporting) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator()
                    Text("書き出し中… $exportProgress%", color = Color.White)
                    LinearProgressIndicator(
                        progress = { exportProgress / 100f },
                        modifier = Modifier.width(240.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayPauseButton(vm: PlayerViewModel) {
    // Poll play state once a frame
    var isPlaying by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        while (true) {
            isPlaying = vm.player.isPlaying
            kotlinx.coroutines.delay(200)
        }
    }
    IconButton(onClick = {
        if (vm.player.isPlaying) vm.player.pause() else vm.player.play()
    }) {
        Icon(
            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            null,
            tint = Color.White
        )
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = if (selected) Color.White else Color.DarkGray,
            contentColor = if (selected) Color.Black else Color.White,
        )
    ) { Text(label) }
}

@Composable
private fun MaskControls(
    state: MaskedRegionState,
    onChange: (MaskedRegionState) -> Unit,
) {
    Column {
        LabeledSlider("X", state.rectX, 0f..1f) { onChange(state.copy(rectX = it)) }
        LabeledSlider("Y", state.rectY, 0f..1f) { onChange(state.copy(rectY = it)) }
        LabeledSlider("W", state.rectW, 0.05f..1f) { onChange(state.copy(rectW = it)) }
        LabeledSlider("H", state.rectH, 0.05f..1f) { onChange(state.copy(rectH = it)) }
        if (state.mode == 1) {
            LabeledSlider("明度", state.brightness, -1f..1f) {
                onChange(state.copy(brightness = it))
            }
        }
        if (state.mode == 2) {
            LabeledSlider("粒度", state.mosaicSize, 0.01f..0.2f) {
                onChange(state.copy(mosaicSize = it))
            }
        }
        LabeledSlider("境界ぼかし", state.feather, 0f..0.2f) {
            onChange(state.copy(feather = it))
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.width(56.dp))
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun MaskRectGuide(mask: MaskedRegionState) {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val x = mask.rectX * size.width
        val y = mask.rectY * size.height
        val w = mask.rectW * size.width
        val h = mask.rectH * size.height
        drawRect(
            color = Color.Cyan,
            topLeft = Offset(x, y),
            size = androidx.compose.ui.geometry.Size(w, h),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f),
            alpha = 0.8f,
        )
    }
}
