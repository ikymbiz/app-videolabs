package com.example.videolab.ui.components

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import kotlin.math.abs

/**
 * Gesture regions (screen-width tri-split):
 *   left third  -> vertical swipe = brightness
 *   right third -> vertical swipe = volume
 *   middle third-> horizontal swipe = seek
 * Two-finger pinch anywhere -> zoom
 * Double-tap left/right -> seek ±10s
 * Single tap -> toggle controls
 */
@Composable
fun GestureOverlay(
    modifier: Modifier = Modifier,
    onBrightnessDelta: (Float) -> Unit,
    onVolumeDelta: (Float) -> Unit,
    onSeekDeltaMs: (Long) -> Unit,
    onZoomPan: (scaleDelta: Float, pan: Offset, centroid: Offset, size: IntSize) -> Unit,
    onDoubleTapLeft: () -> Unit,
    onDoubleTapRight: () -> Unit,
    onTap: () -> Unit,
) {
    val density = LocalDensity.current

    Box(
        modifier = modifier
            .fillMaxSize()
            // Tap / double tap
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { offset ->
                        if (offset.x < size.width / 2f) onDoubleTapLeft() else onDoubleTapRight()
                    }
                )
            }
            // Multi-touch pinch for zoom
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var prevDistance = 0f
                    var prevCentroid = Offset.Zero
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Main)
                        if (event.changes.none { it.pressed }) break
                        if (event.changes.size >= 2) {
                            val p1 = event.changes[0].position
                            val p2 = event.changes[1].position
                            val dx = p2.x - p1.x
                            val dy = p2.y - p1.y
                            val distance = kotlin.math.hypot(dx, dy)
                            val centroid = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)

                            if (prevDistance > 0f) {
                                val scaleDelta = distance / prevDistance
                                val pan = centroid - prevCentroid
                                onZoomPan(scaleDelta, pan, centroid, size)
                            }
                            prevDistance = distance
                            prevCentroid = centroid
                            event.changes.forEach { it.consume() }
                        } else {
                            prevDistance = 0f
                        }
                    }
                }
            }
            // Single-finger swipe regions
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startX = down.position.x
                    val startY = down.position.y
                    val w = size.width
                    val region = when {
                        startX < w / 3f -> Region.Brightness
                        startX > w * 2 / 3f -> Region.Volume
                        else -> Region.Seek
                    }
                    var lastX = startX
                    var lastY = startY
                    var consumed = false

                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Main)
                        // Bail out if pinch takes over
                        if (event.changes.size >= 2) break

                        val change: PointerInputChange = event.changes.first()
                        if (!change.pressed) break
                        if (change.positionChanged()) {
                            val cur = change.position
                            val dx = cur.x - lastX
                            val dy = cur.y - lastY
                            lastX = cur.x
                            lastY = cur.y

                            when (region) {
                                Region.Brightness -> {
                                    if (abs(dy) > 1f) {
                                        // upward = brighter
                                        onBrightnessDelta(-dy / size.height * 1.5f)
                                        consumed = true
                                    }
                                }
                                Region.Volume -> {
                                    if (abs(dy) > 1f) {
                                        onVolumeDelta(-dy / size.height * 1.5f)
                                        consumed = true
                                    }
                                }
                                Region.Seek -> {
                                    if (abs(dx) > 1f) {
                                        // 1 screen width = 60 seconds
                                        val deltaMs = (dx / size.width * 60_000f).toLong()
                                        onSeekDeltaMs(deltaMs)
                                        consumed = true
                                    }
                                }
                            }
                            if (consumed) change.consume()
                        }
                    }
                }
            }
    )
}

private enum class Region { Brightness, Volume, Seek }
