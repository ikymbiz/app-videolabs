package com.example.videolab.player

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.videolab.effect.MaskedRegionEffect
import com.example.videolab.effect.MaskedRegionState
import com.example.videolab.effect.ZoomPanEffect
import com.example.videolab.effect.ZoomPanState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@UnstableApi
class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    // --- State flows consumed by UI and also by shaders through provider lambdas ---
    private val _zoomPan = MutableStateFlow(ZoomPanState())
    val zoomPan: StateFlow<ZoomPanState> = _zoomPan.asStateFlow()

    private val _mask = MutableStateFlow(MaskedRegionState())
    val mask: StateFlow<MaskedRegionState> = _mask.asStateFlow()

    private val _speed = MutableStateFlow(1f)
    val speed: StateFlow<Float> = _speed.asStateFlow()

    private val _brightnessOverlay = MutableStateFlow(0f) // system-like screen brightness -1..+1
    val brightnessOverlay: StateFlow<Float> = _brightnessOverlay.asStateFlow()

    private val _volume = MutableStateFlow(1f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    var videos: List<Uri> = emptyList()
        private set

    val player: ExoPlayer by lazy {
        ExoPlayer.Builder(getApplication()).build().also { p ->
            p.playWhenReady = true
        }
    }

    fun setVideos(uris: List<Uri>, startIndex: Int) {
        videos = uris
        _currentIndex.value = startIndex
        loadCurrent()
        applyEffects()
    }

    private fun loadCurrent() {
        val uri = videos.getOrNull(_currentIndex.value) ?: return
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
    }

    fun next() {
        if (_currentIndex.value < videos.lastIndex) {
            _currentIndex.value += 1
            loadCurrent()
        }
    }

    fun prev() {
        if (_currentIndex.value > 0) {
            _currentIndex.value -= 1
            loadCurrent()
        }
    }

    fun setSpeed(speed: Float) {
        _speed.value = speed
        // Pitch = 1f preserves audio pitch
        player.playbackParameters = PlaybackParameters(speed, 1f)
    }

    fun setVolume(v: Float) {
        _volume.value = v.coerceIn(0f, 1f)
        player.volume = _volume.value
    }

    fun adjustVolume(delta: Float) = setVolume(_volume.value + delta)
    fun adjustBrightness(delta: Float) {
        _brightnessOverlay.value = (_brightnessOverlay.value + delta).coerceIn(-1f, 1f)
    }

    fun updateZoom(block: (ZoomPanState) -> ZoomPanState) {
        _zoomPan.value = block(_zoomPan.value)
    }

    fun updateMask(block: (MaskedRegionState) -> MaskedRegionState) {
        _mask.value = block(_mask.value)
    }

    fun seekBy(deltaMs: Long) {
        player.seekTo((player.currentPosition + deltaMs).coerceAtLeast(0))
    }

    /**
     * Assembles the list of effects. Same list is used for preview AND export
     * to guarantee WYSIWYG output.
     */
    fun buildEffects(): List<Effect> = listOf(
        MaskedRegionEffect { _mask.value },
        ZoomPanEffect { _zoomPan.value },
    )

    private fun applyEffects() {
        player.setVideoEffects(buildEffects())
    }

    override fun onCleared() {
        super.onCleared()
        player.release()
    }
}
