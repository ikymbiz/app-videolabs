package com.example.videolab

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.videolab.ui.PlayerScreen
import com.example.videolab.ui.VideoListScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VideoLabApp()
        }
    }
}

@Composable
fun VideoLabApp() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            var selectedVideos by remember { mutableStateOf<List<Uri>>(emptyList()) }
            var selectedIndex by remember { mutableStateOf<Int?>(null) }

            val currentIndex = selectedIndex
            if (currentIndex == null) {
                VideoListScreen(
                    onVideoSelected = { videos, index ->
                        selectedVideos = videos
                        selectedIndex = index
                    }
                )
            } else {
                PlayerScreen(
                    videos = selectedVideos,
                    startIndex = currentIndex,
                    onExit = { selectedIndex = null }
                )
            }
        }
    }
}
