package com.example.videolab.ui

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.videolab.data.VideoItem
import com.example.videolab.data.VideoRepository
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlin.time.Duration.Companion.milliseconds

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun VideoListScreen(
    onVideoSelected: (videos: List<Uri>, index: Int) -> Unit,
) {
    val context = LocalContext.current
    val repo = remember { VideoRepository(context) }

    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    val permState = rememberPermissionState(permission)

    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(permState.status.isGranted) {
        if (permState.status.isGranted) {
            loading = true
            videos = repo.queryVideos()
            loading = false
        }
    }

    if (!permState.status.isGranted) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "動画ファイルへのアクセス許可が必要です",
                    color = Color.White
                )
                Button(onClick = { permState.launchPermissionRequest() }) {
                    Text("許可する")
                }
            }
        }
        return
    }

    if (loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("読み込み中…", color = Color.White)
        }
        return
    }

    if (videos.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("動画が見つかりません", color = Color.White)
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(videos) { video ->
            val idx = videos.indexOf(video)
            ListItem(
                modifier = Modifier.clickable {
                    onVideoSelected(videos.map { it.uri }, idx)
                },
                leadingContent = {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = Color.White
                    )
                },
                headlineContent = {
                    Text(video.displayName, color = Color.White, maxLines = 1)
                },
                supportingContent = {
                    val mins = video.durationMs.milliseconds.inWholeMinutes
                    val secs = (video.durationMs.milliseconds.inWholeSeconds % 60)
                    val sizeMb = video.sizeBytes / (1024 * 1024)
                    Text(
                        "%02d:%02d · %d MB".format(mins, secs, sizeMb),
                        color = Color.Gray
                    )
                },
                colors = ListItemDefaults.colors(containerColor = Color.Black)
            )
        }
    }
}
