package com.example.videolab.effect

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram

/**
 * Masked region effect:
 *  - EffectMode 0 = passthrough
 *  - EffectMode 1 = brightness (+/-) inside rect with feather
 *  - EffectMode 2 = mosaic inside rect with feather
 *
 * Rect is given in normalized UV (0..1) of the video frame.
 *
 * Uses standard Media3 BaseGlShaderProgram conventions:
 *  attribute aFramePosition (vec4) - NDC quad
 *  uniform   uTexSampler  (sampler2D) - input texture (already 2D, not external OES)
 *  uniform   uTexTransformationMatrix (mat4) - Media3 sample transform
 *  uniform   uTransformationMatrix    (mat4) - Media3 position transform
 */
@UnstableApi
class MaskedRegionShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val stateProvider: () -> MaskedRegionState,
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private val glProgram: GlProgram = GlProgram(
        VERTEX_SHADER,
        FRAGMENT_SHADER,
    ).apply {
        // Fullscreen quad in NDC
        setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
        )
        // Identity matrices - Media3 normally sets these; we default to identity.
        setFloatsUniform("uTexTransformationMatrix", GlUtil.create4x4IdentityMatrix())
        setFloatsUniform("uTransformationMatrix", GlUtil.create4x4IdentityMatrix())
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            val s = stateProvider()
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
            glProgram.setIntUniform("uEffectMode", s.mode)
            glProgram.setFloatsUniform(
                "uMaskRect",
                floatArrayOf(s.rectX, s.rectY, s.rectW, s.rectH),
            )
            glProgram.setFloatUniform("uBrightness", s.brightness)
            glProgram.setFloatUniform("uFeather", s.feather)
            glProgram.setFloatUniform("uMosaicSize", s.mosaicSize)
            glProgram.bindAttributesAndUniforms()

            // Render fullscreen quad
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, /* first= */ 0, /* count= */ 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            // best-effort
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            #version 100
            attribute vec4 aFramePosition;
            uniform mat4 uTransformationMatrix;
            uniform mat4 uTexTransformationMatrix;
            varying vec2 vTexSamplingCoord;
            void main() {
              gl_Position = uTransformationMatrix * aFramePosition;
              vec4 tex = uTexTransformationMatrix * vec4(
                aFramePosition.x * 0.5 + 0.5,
                aFramePosition.y * 0.5 + 0.5,
                0.0, 1.0);
              vTexSamplingCoord = tex.xy;
            }
        """

        private const val FRAGMENT_SHADER = """
            #version 100
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform vec4  uMaskRect;   // x, y, w, h (normalized)
            uniform float uBrightness; // -1..+1
            uniform float uFeather;    // 0..0.2
            uniform int   uEffectMode; // 0=off, 1=brightness, 2=mosaic
            uniform float uMosaicSize; // 0.01..0.2
            varying vec2 vTexSamplingCoord;

            void main() {
              vec2 uv = vTexSamplingCoord;
              vec2 rectMin = uMaskRect.xy;
              vec2 rectMax = uMaskRect.xy + uMaskRect.zw;

              // Feathered rectangular mask weight
              float wx = smoothstep(rectMin.x - uFeather, rectMin.x + uFeather * 0.001, uv.x)
                       * (1.0 - smoothstep(rectMax.x - uFeather * 0.001, rectMax.x + uFeather, uv.x));
              float wy = smoothstep(rectMin.y - uFeather, rectMin.y + uFeather * 0.001, uv.y)
                       * (1.0 - smoothstep(rectMax.y - uFeather * 0.001, rectMax.y + uFeather, uv.y));
              float mask = wx * wy;

              vec2 sampleUv = uv;

              if (uEffectMode == 2 && mask > 0.0 && uMaskRect.z > 0.0 && uMaskRect.w > 0.0) {
                // Quantize UV within rect to create mosaic
                vec2 local = (uv - rectMin) / uMaskRect.zw;
                vec2 cells = vec2(max(1.0, 1.0 / uMosaicSize));
                local = (floor(local * cells) + 0.5) / cells;
                vec2 snappedUv = rectMin + local * uMaskRect.zw;
                sampleUv = mix(uv, snappedUv, mask);
              }

              vec4 color = texture2D(uTexSampler, sampleUv);

              if (uEffectMode == 1) {
                color.rgb = clamp(color.rgb + vec3(uBrightness) * mask, 0.0, 1.0);
              }

              gl_FragColor = color;
            }
        """
    }
}

data class MaskedRegionState(
    /** 0=off, 1=brightness, 2=mosaic */
    val mode: Int = 0,
    /** Rect in normalized UV (0..1, origin top-left) */
    val rectX: Float = 0.25f,
    val rectY: Float = 0.25f,
    val rectW: Float = 0.5f,
    val rectH: Float = 0.5f,
    /** -1..+1 */
    val brightness: Float = 0f,
    /** 0..0.2 */
    val feather: Float = 0.02f,
    /** 0.01..0.2 — smaller = finer mosaic */
    val mosaicSize: Float = 0.05f,
)
