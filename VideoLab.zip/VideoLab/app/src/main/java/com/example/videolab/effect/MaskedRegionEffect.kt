package com.example.videolab.effect

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/** Wraps MaskedRegionShaderProgram so it can be passed to Media3's effect pipeline. */
@UnstableApi
class MaskedRegionEffect(
    private val stateProvider: () -> MaskedRegionState,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return MaskedRegionShaderProgram(context, useHdr, stateProvider)
    }
}
